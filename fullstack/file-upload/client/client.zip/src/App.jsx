import React from 'react'
import Profile from './pages/Profile'

const App = () => {
  return <>
    <Profile />
  </>


}

export default App